for (let i = 1; j < 13; i++) {
    for (let i = 1; j < 13; j++) {
        console.log(`${j} multiplied by ${i} is ${i*j}`);
    }
}
//    The outer loop counts up from i=1 to i=12 . For every iteration 
//of the outer loop, the inner loop counts up from j=1 to j=12 . 
//This means that it starts in the first iteration with i = 1 and j = 1 , 
//producing the following output that is logged to the console: